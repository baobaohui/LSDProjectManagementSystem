// pages/proj_list/proj_list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: 1,
    act_msg: [{
        proj_name: '微信小程序',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠',
      },

      {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
      {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
      {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
      {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
      {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
       {
        proj_name: '微信小程序02',
        proj_time: '时间:09月01日 周日 17:00',
        proj_leader: '吴楠02',
      },
    ],

  },
  change: function(e) {
    console.log(e);
    this.setData({
      num: e.target.dataset.num
    })
  },
  send: function(e) {
    wx.navigateTo({
      url: '../create_proj/create_proj',
    })
  },
  boss_proj_detail: function(e) {
    wx.navigateTo({
      url: '../boss_proj_detail/boss_proj_detail',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})