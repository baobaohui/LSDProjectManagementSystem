// pages/salesman_voicemail/salesman_voicemail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    voicemail: [{
      
      message: '项目做的不错',
      message_time: '2019/8/30',
    },

    {
    
      message: '李市长那里给的有点多了，告诉他，如果不愿意合作的话就结束合作关系，然后你去王市长那里，我已经打过招呼了，最晚明天解决这个事情',
      message_time: '2019/8/31',
    },
    ],
  },
  salesman_proj_detail: function (e) {
    wx.navigateTo({
      url: '../salesman_proj_detail/salesman_proj_detail',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})